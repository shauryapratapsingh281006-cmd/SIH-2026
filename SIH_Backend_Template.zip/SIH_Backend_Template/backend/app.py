from flask import Flask, jsonify, request
import os
from dotenv import load_dotenv
load_dotenv()
app=Flask(__name__)
API_KEY=os.getenv("GOOGLE_MAPS_API_KEY")

@app.route('/location',methods=['POST'])
def location():
    data=request.json
    return jsonify(data)

@app.route('/redzone/<lat>/<lng>')
def redzone(lat,lng):
    return jsonify({"Latitude":lat,"Longitude":lng,"Risk":"HIGH"})

@app.route('/satellite/<lat>/<lng>')
def satellite(lat,lng):
    url=f"https://maps.googleapis.com/maps/api/staticmap?center={lat},{lng}&zoom=16&size=800x800&maptype=satellite&key={API_KEY}"
    return jsonify({"satellite":url})

if __name__=='__main__':
    app.run(debug=True)
