navigator.geolocation.getCurrentPosition(p=>{
fetch('http://127.0.0.1:5000/location',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({latitude:p.coords.latitude,longitude:p.coords.longitude})})
})