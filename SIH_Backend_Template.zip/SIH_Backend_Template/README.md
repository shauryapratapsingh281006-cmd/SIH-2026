# SIH Backend Template
Run: pip install -r backend/requirements.txt
